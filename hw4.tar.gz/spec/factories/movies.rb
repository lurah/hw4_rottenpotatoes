FactoryGirl.define do
  factory :movie do |f|
    f.title         "First Movie"
    f.rating        "PG"
    f.director      "Garin Nugroho"
    f.release_date  "01/01/2000"
  end
end

